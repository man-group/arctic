from __future__ import absolute_import

import logging as logger

logger.basicConfig(format='%(asctime)s %(message)s', level='INFO')
logger = logger.getLogger('arctic')
